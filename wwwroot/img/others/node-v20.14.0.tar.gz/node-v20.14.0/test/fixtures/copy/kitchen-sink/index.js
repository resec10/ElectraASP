module.exports = {
  purpose: 'testing copy'
};
