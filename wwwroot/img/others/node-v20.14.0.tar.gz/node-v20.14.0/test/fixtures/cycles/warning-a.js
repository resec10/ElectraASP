require('./warning-b.js');
