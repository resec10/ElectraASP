const a = require('./warning-esm-half-transpiled-a.js');
a.__esModule;
