require('./warning-moduleexports-b.js').missingPropModuleExportsB;
