# Usage and Example

CJS snippet is first, it should be the one displayed by default.

```cjs
require('path');
```

```mjs
import 'node:url';
```