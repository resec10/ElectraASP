'use strict';

// test we can use commonjs require
require('path');
console.log('executed');
