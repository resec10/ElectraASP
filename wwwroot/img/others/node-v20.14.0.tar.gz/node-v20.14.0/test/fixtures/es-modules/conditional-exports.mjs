export { default } from 'pkgexports/condition';
