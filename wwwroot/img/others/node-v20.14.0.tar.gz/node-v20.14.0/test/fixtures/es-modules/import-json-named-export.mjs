import { ofLife } from '../experimental.json' with { type: 'json' };
