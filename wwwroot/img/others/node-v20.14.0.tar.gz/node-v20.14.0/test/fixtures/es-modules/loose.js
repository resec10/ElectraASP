// This file can be run or imported only if `--experimental-default-type=module` is set.
export default 'module';
console.log('executed');
