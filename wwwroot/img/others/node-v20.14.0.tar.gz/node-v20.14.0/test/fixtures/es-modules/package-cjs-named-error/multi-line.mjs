import {
  comeOn,
  everybody,
} from './fail.cjs';
