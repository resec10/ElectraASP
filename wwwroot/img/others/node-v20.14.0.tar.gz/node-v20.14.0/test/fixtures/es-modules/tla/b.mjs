import order from './order.mjs';

order.push('b');
