import order from './order.mjs';

order.push('c');
