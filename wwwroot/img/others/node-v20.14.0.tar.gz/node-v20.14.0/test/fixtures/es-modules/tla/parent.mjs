import order from './order.mjs';
import './a.mjs';
import './b.mjs';
import './c.mjs';
import './d.mjs';

order.push('parent');

export default order;
