'use strict';

require('../common');

global.gc = 42; // intentionally leak a global
