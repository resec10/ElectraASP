"use strict";
exports.__esModule = true;
require("./throw-on-require");
//# sourceMappingURL=throw-on-require-entry.js.map
