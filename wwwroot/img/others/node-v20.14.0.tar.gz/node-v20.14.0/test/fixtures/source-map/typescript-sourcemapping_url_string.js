"use strict";
const content = '//# sourceMappingURL=';
throw new Error('an exception.');
//# sourceMappingURL=typescript-sourcemapping_url_string.js.map
