'use strict';
const test = require('node:test');

test('this should pass');
