'use strict';
const test = require('node:test');

test('this should be skipped');
test('this should be executed');
