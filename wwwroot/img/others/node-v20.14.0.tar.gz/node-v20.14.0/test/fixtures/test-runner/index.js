'use strict';
throw new Error('thrown from index.js');
