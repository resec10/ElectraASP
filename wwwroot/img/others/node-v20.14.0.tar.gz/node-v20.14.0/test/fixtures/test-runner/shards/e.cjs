'use strict';
const test = require('node:test');

test('e.cjs this should pass');
