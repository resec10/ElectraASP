'use strict';
const test = require('node:test');

test('f.cjs this should pass');
