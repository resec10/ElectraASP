﻿#!shebang
#!shebang
module.exports = 42;